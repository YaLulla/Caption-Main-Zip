class Translation(object):

      
      START_TEXT = """
🍃 **ʜᴀɪ** __{}__ , 

😴😴 I am Sleeping don't Disturb Me , I will Kill you !

😈 __ᴍᴀɪɴᴛᴀɪɴᴇᴅ ʙʏ__ 👉 __@{}__
"""    

      HELP_TEXT = """
<u>💡 𝐇𝐞𝐥𝐩</u> 

👉 <i>Add me as a Admin in your channel with edit permission</i>

👉 <i>Add your caption in heroku Config Var</i>
   
<i>[Support Markdown]</i>

👉 <i>Forward your files in your channel and I will edit it</i>

○ <i>My Source Code : /source</i>

"""    
              

     
      ABOUT_TEXT = """
📕 **𝐀𝐛𝐨𝐮𝐭 𝐌𝐞**

__○ ᴍʏ ɴᴀᴍᴇ : [CapXbot](https://t.me/Avishkarpatil)__
__○ ʟᴀɴɢᴜᴀɢᴇ : ᴘʏᴛʜᴏɴ __
__○ ғʀᴀᴍᴇᴡᴏʀᴋ : ᴘʏʀᴏɢʀᴀᴍ __
__○ sᴇʀᴠᴇʀ : ʜᴇʀᴏᴋᴜ __
__○ ᴠᴇʀsɪᴏɴ : 2.0.1__
__○ ᴄʀᴇᴀᴛᴏʀ :  @AvishkarPatil__
 
**[© ᴀᴠɪsʜᴋᴀʀ ᴘᴀᴛɪʟ](https://t.me/Avishkarpatil)**
"""

      MARKDOWN_TEXT = """
🔰 <u>𝐀𝐛𝐨𝐮𝐭 𝐌𝐚𝐫𝐤𝐝𝐨𝐰𝐧</u>
👉 <b>Bold text</b>
🔸 <code>**Avishkar**</code>

👉 <b>Italic text</b>
🔹 <code>__Avishkat__</code> 

👉 <b>Code text</b>
🔸 <code>`Avishkar`</code>   

👉 <b>Hyperlink text</b>
🔹 <code>[hyperlink_text](https://avipatilweb.me)</code> 

〰〰〰〰〰〰〰〰〰〰

<b><a href="https://t.me/Avishkarpatil">© ᴀᴠɪsʜᴋᴀʀ ᴘᴀᴛɪʟ</a></b>
"""

# Bot status display

      STATUS_DATA = """
🔰 <u>𝐁𝐎𝐓 𝐒𝐓𝐀𝐓𝐔𝐒</u>

🖌️ <b>Current Caption :</b> 
{}

📐 <b>Current Position :</b> {}

<b><a href="https://t.me/Avishkarpatil">© ᴀᴠɪsʜᴋᴀʀ ᴘᴀᴛɪʟ</a></b>
"""


      SOURCE_TEXT = """

○ <b> I Am Available Open Source on Github 
      Click Below Link And Deploy Me Now </b>

○ <i>DEPLOY</i> : <b><a href="https://heroku.com/deploy?template=https://github.com/avipatilpro/Caption-Bot">On Heroku</a></b>    

○ <i>SOURCE</i> : <b><a href="https://github.com/avipatilpro/Caption-Bot">Caption Bot</a></b>  
"""
