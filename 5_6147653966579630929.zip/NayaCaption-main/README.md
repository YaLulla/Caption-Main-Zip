<h1 align='center'>🖊️ TG AutoCaption Bot </h1>


<h4 align='center'>Bot Used For Auto Caption For Telegram Files & Video With Custom Text<br><br><i>(Only in channels either public or private Telegram channel)</i> </h4><br>


<h4 align='center'>✯ Demo Bot ✯<br></h4>
<h3 align='center' ><b><a href="https://telegram.me/CapXBot">¢αρтισи вσт</a></b></h3>


###  Config Vars :

- ```CAPTION_TEXT``` - Caption Below File [ Markdown ]

- ```CAPTION_POSITION``` - Position of Your Caption According to File Name [ Top, Bottom, or Nil ]
<br>

### Deploy :

- Fork This Repo
- Without Any Changes Click Below Button 
- Deploy This Repo

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
<br>


### Commands :

```
/start - A command to start the bot
/help  - A command to help you how to use the bot
/about - A command to know about the bot
/source - A Command to Looks about Source Code
```
### Thanks :

- [Avishkar Patil](https://github.com/avipatilpro)
- [Ts_Bots](https://github.com/Ts-Bots)
